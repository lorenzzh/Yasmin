document.getElementById("showMessage").addEventListener("click", function() {
    document.getElementById("message").classList.toggle("hidden");
});